# Changelog

All notable changes to this package will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/)
and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).

## [Unreleased]

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [17.0.3] - 2025-02-13

This version is compatible with Unity 6000.2.0a1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [17.0.2] - 2024-04-02

This version is compatible with Unity 6000.0.0b15.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [17.0.1] - 2023-12-21

This version is compatible with Unity 2023.3.0b2.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [17.0.0] - 2023-09-26

This version is compatible with Unity 2023.3.0a8.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [16.0.3] - 2023-07-04

This version is compatible with Unity 2023.3.0a1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [16.0.2] - 2023-06-28

This version is compatible with Unity 2023.2.0a22.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [16.0.1] - 2023-05-23

This version is compatible with Unity 2023.2.0a17.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [16.0.0] - 2023-03-22

This version is compatible with Unity 2023.2.0a9.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [15.0.3] - 2022-12-02

This version is compatible with Unity 2023.2.0a1.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [15.0.2] - 2022-11-04

This version is compatible with Unity 2023.1.0a23.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [15.0.1] - 2022-08-04

This version is compatible with Unity 2023.1.0a19.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [15.0.0] - 2022-06-13

This version is compatible with Unity 2023.1.0a6.

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.3] - 2021-05-09

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.2] - 2021-02-04

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.1] - 2021-12-07

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [14.0.0] - 2021-11-17

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.1.2] - 2021-11-05

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.1.1] - 2021-10-04

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.1.0] - 2021-09-24

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [13.0.0] - 2021-09-01

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [12.0.0] - 2021-01-11

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [11.0.0] - 2020-10-21

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [10.2.0] - 2020-10-19

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [10.1.0] - 2020-10-12

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [10.0.0] - 2019-06-10

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.1.1] - 2019-09-05

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

## [7.0.1] - 2019-07-25

Version Updated
The version number for this package has increased due to a version update of a related graphics package.

Started Changelog

using UnityEngine;

public class MazeLoader : MonoBehaviour
{
    public GameObject AbsorbentCube;
    public GameObject ReflectiveCube;
    public GameObject TransparentCube;
    public float cellSize = 1.0f;

    [System.Serializable]
    private class LightData
    {
        public float x;
        public float z;
        public float intensity;
        public string color;
    }

    [System.Serializable]
    private class MazeData
    {
        public int width;
        public int height;
        public string[] layout;
        public LightData[] lights; 
    }

    void Start()
    {
        TextAsset jsonFile = Resources.Load<TextAsset>("config");
        if (jsonFile == null)
        {
            Debug.LogError("Maze config file not found!");
            return;
        }

        MazeData maze = JsonUtility.FromJson<MazeData>(jsonFile.text);
        if (maze.layout == null || maze.layout.Length != maze.width * maze.height)
        {
            Debug.LogError("Maze layout is missing or invalid.");
            return;
        }

        int index = 0;
        for (int row = 0; row < maze.height; row++)
        {
            for (int col = 0; col < maze.width; col++)
            {
                string type = maze.layout[index];

                if (type != "0")
                {
                    Vector3 pos = new Vector3(row, 0, col);

                    if (type == "A")
                        Instantiate(AbsorbentCube, pos, Quaternion.identity);
                    else if (type == "R")
                        Instantiate(ReflectiveCube, pos, Quaternion.identity);
                    else if (type == "T")
                        Instantiate(TransparentCube, pos, Quaternion.identity);
                }

                index++;
            }
        }

       
        if (maze.lights != null)
        {
            foreach (var lightData in maze.lights)
            {
                GameObject lightGO = new GameObject("MazeLight");
                Light lightComp = lightGO.AddComponent<Light>();
                lightComp.type = LightType.Point;
                lightComp.intensity = lightData.intensity;

                if (ColorUtility.TryParseHtmlString(lightData.color, out Color parsedColor))
                    lightComp.color = parsedColor;

                lightGO.transform.position = new Vector3(lightData.x, 2f, lightData.z);
            }
        }

        Debug.Log("Maze generated with blocks and lights.");
    }
}
